package com.test;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PersonServiceImp implements PersonService {

	@Autowired
    private SQLConfigDAO configDAO;
	


		@Override
	    @Transactional(readOnly = true)
		public List<SQLConfig> listConfigs() {
			// TODO Auto-generated method stub
			return configDAO.listConfigs();
		}

}
