package com.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
	   public static void main(String[] args) {
		      AnnotationConfigApplicationContext context = 
		            new AnnotationConfigApplicationContext(AppConfig.class);

		      PersonService personService = context.getBean(PersonService.class);


		      // Get Persons
		      List<SQLConfig> persons = personService.listConfigs();
		      System.out.println("****** INSERT ******");
		      persons.forEach(System.out::println);
//		      for (SQLConfig person : persons) {
//		         System.out.println("Id = "+person.getId());
//		         System.out.println("First Name = "+person.getFirstName());
//		         System.out.println("Last Name = "+person.getLastName());
//		         System.out.println("Email = "+person.getEmail());
//		         System.out.println();
//		      }

		      context.close();
		   }

}
