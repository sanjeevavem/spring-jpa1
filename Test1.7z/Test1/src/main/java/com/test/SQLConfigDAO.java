package com.test;

import java.util.List;

public interface SQLConfigDAO {
	 List<SQLConfig> listConfigs();
}
