package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

@Repository
public class SQLConfigDAOImpl implements SQLConfigDAO {

	  @PersistenceContext
	  private EntityManager em;
	  
	@Override
	public List<SQLConfig> listConfigs() {
		// TODO Auto-generated method stub
	     CriteriaQuery<SQLConfig> criteriaQuery = em.getCriteriaBuilder().createQuery(SQLConfig.class);
	      @SuppressWarnings("unused")
	      Root<SQLConfig> root = criteriaQuery.from(SQLConfig.class);
	      return em.createQuery(criteriaQuery).getResultList();
	}

}
