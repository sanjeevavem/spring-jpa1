package com.test;

import java.util.List;

public interface PersonService {
	 List<SQLConfig> listConfigs();
}
